import express from "express";
import { fileURLToPath } from "url";
import {
  ACCOUNT_CODE,
  createCheckoutSession,
  getPaymentMethods,
  createPayment,
  getNuPayPaymentConditions,
  CUSTOMER_ID,
} from "./yuno.js";
import path, { dirname } from "path";
import * as uuid from "uuid";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const indexPage = path.join(__dirname, "index.html");
const sdkLitePage = path.join(__dirname, "sdk-lite.html");
const staticDirectory = path.join(__dirname, "static");

const app = express();

app.use(express.json());
app.use("/static", express.static(staticDirectory));

app.get("/", (req, res) => {
  res.sendFile(indexPage);
});

app.get("/sdk-lite.html", (req, res) => {
  res.sendFile(sdkLitePage);
});

// Endpoint que cria a session de checkout
app.post("/checkout/sessions", async (req, res) => {
  // Simulando Criação do Pedido
  const order = {
    account_id: ACCOUNT_CODE,
    merchant_order_id: "1655401222",
    payment_description: "Test MP 1654536326",
    country: "BR",
    customer_id: CUSTOMER_ID,
    amount: {
      value: 2000,
      currency: "BRL",
    },
  };

  // Criar o Checkout Session com a Yuno
  const response = await createCheckoutSession(order);

  // Retorna esse checkout session.
  res.json(response);
});

// Endpoint que cria o pagamento com a yuno.
app.post("/payments", async (req, res) => {
  const country = "BR";
  const oneTimeToken = req.body.oneTimeToken;
  const checkoutSession = req.body.checkoutSession;

  // Simulando Buscando Dados do Pedido e do Cliente
  const { currency, documentNumber, documentType, amount } = {
    documentType: "CPF",
    documentNumber: "351.040.753-97",
    currency: "BRL",
    amount: 2000,
  };

  // Simulando Criação do Pagamento do Lado do Merchant
  const payment = {
    description: "Test Addi",
    account_id: ACCOUNT_CODE,
    merchant_order_id: "1655401222",
    country,
    amount: {
      currency,
      value: amount,
    },
    checkout: {
      session: checkoutSession,
    },
    customer_payer: {
      billing_address: {
        address_line_1: "Calle 34 # 56 - 78",
        address_line_2: "Apartamento 502, Torre I",
        city: "Bogota",
        country,
        state: "Cundinamarca",
        zip_code: "111111",
      },
      shipping_address: {
        address_line_1: "Calle 34 # 56 - 78",
        address_line_2: "Apartamento 502, Torre I",
        city: "Bogota",
        country,
        state: "Cundinamarca",
        zip_code: "111111",
      },
      document: {
        document_type: documentType,
        document_number: documentNumber,
      },
      id: CUSTOMER_ID,
      nationality: "BR",
    },
    payment_method: {
      type: "GOOGLE_PAY",
      token: oneTimeToken,
      vaulted_token: null,
    },
  };

  // Executando Pagamento na Yuno
  const idempotencyKey = uuid.v4();
  const response = await createPayment(idempotencyKey, payment);

  res.json(response);
});

app.get("/payment-methods/:checkoutSession", async (req, res) => {
  const checkoutSession = req.params.checkoutSession;
  const paymentMethods = await getPaymentMethods(checkoutSession);
  res.json(paymentMethods);
});

// NuPay Payment Conditions Endpoint
app.post("/nupay/payment-conditions", async (req, res) => {
  const { amount, document } = req.body;

  try {
    // Simulating NuPay Payment Conditions API call
    // In production, this would call SpinPay API
    const paymentConditions = await getNuPayPaymentConditions(amount, document);
    res.json(paymentConditions);
  } catch (error) {
    console.error("NuPay Payment Conditions error:", error);
    res.status(400).json({
      status: 400,
      message: "Payment options not available",
      details: {},
    });
  }
});

// Roda minha API (Sobe o Web Server)
const SERVER_PORT = 8080;
app.listen(SERVER_PORT, () => {
  console.log(`Server is running at: http://localhost:${SERVER_PORT}`);
});
